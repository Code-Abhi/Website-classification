<?php

	$con=mysqli_connect("localhost","root","","website_classification");

?>