import pandas as pd
import re
import urllib.request
from bs4 import BeautifulSoup


def preprocess_text(sen):
    sentence = remove_tags(sen)
    sentence = re.sub('[^a-zA-Z]', ' ', sentence)
    sentence = re.sub(r"\s+[a-zA-Z]\s+", ' ', sentence)
    sentence = re.sub(r'\s+', ' ', sentence)
    return sentence

def remove_tags(text):
    TAG_RE = re.compile(r'<[^>]+>')
    return TAG_RE.sub('', text)

file = open("url.txt", "r", encoding='utf-8')
url = file.read()
file.close()

x = []
html = urllib.request.urlopen(url)
htmlParse = BeautifulSoup(html, 'html.parser')

for para in htmlParse.find_all("p"):
    x.append(para.get_text())

text = ""
for i in x:
    text += " " + str(i)
text = text.strip()

processed_text = preprocess_text(text)

with open("out.txt", "w") as file:
    file.write(processed_text)
