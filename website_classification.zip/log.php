<?php
session_start();
include('connection.php');

if (isset($_POST['login']))
{   
    $username = $_POST['email']; 
    $password = $_POST['password']; 

    $sel = "SELECT * FROM reg WHERE email='$username' and password='$password'";
    $result = mysqli_query($con, $sel);
    
    if ($result)
    {
        $row = mysqli_fetch_array($result);
        $rows = mysqli_num_rows($result);
    
        if ($rows == 1)
        {   
            $_SESSION['user'] = $row['id'];
            header("location:upload.php");
        }
        else
        {
            // Handle login failure
            // header("location:index.php?a=1");
        }
    }
    else
    {
        // Handle query execution failure
        // For example, you can log the error or redirect to an error page
    }
}
?>
